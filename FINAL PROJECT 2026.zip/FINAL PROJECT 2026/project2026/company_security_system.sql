-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2026 at 09:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `company_security_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`log_id`, `user_id`, `activity`, `ip_address`, `status`, `timestamp`) VALUES
(425, 5, 'User Login', '::1', 'success', '2026-04-08 16:37:20'),
(426, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:37:20'),
(427, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:37:45'),
(428, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:37:47'),
(429, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:37:48'),
(430, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:37:50'),
(431, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:37:53'),
(432, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:37:54'),
(433, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:37:56'),
(434, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:37:57'),
(435, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:38:00'),
(436, 5, 'Viewed Alerts', '::1', 'success', '2026-04-08 16:38:17'),
(437, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:38:22'),
(438, 5, 'Viewed Activity Logs', '::1', 'success', '2026-04-08 16:38:24'),
(439, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:38:38'),
(440, 5, 'Viewed Reports', '::1', 'success', '2026-04-08 16:38:46'),
(441, 5, 'Viewed Report ID: 9', '::1', 'success', '2026-04-08 16:39:12'),
(442, 5, 'Viewed Reports', '::1', 'success', '2026-04-08 16:45:34'),
(443, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:36'),
(444, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:43'),
(445, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:44'),
(446, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:45'),
(447, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:46'),
(448, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:47'),
(449, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:48'),
(450, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:49'),
(451, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:50'),
(452, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:51'),
(453, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:52'),
(454, 5, 'Viewed Alerts', '::1', 'success', '2026-04-08 16:45:55'),
(455, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:45:59'),
(456, 5, 'Viewed Reports', '::1', 'success', '2026-04-08 16:46:02'),
(457, 5, 'Viewed Report ID: 10', '::1', 'success', '2026-04-08 16:46:05'),
(458, 5, 'Viewed Reports', '::1', 'success', '2026-04-08 16:47:50'),
(459, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:47:52'),
(460, 5, 'Viewed Activity Logs', '::1', 'success', '2026-04-08 16:47:54'),
(461, 5, 'Viewed Activity Logs', '::1', 'success', '2026-04-08 16:54:12'),
(462, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 16:55:34'),
(463, 5, 'Viewed Activity Logs', '::1', 'success', '2026-04-08 17:05:26'),
(464, 5, 'Viewed Reports', '::1', 'success', '2026-04-08 17:51:49'),
(465, 5, 'Viewed Alerts', '::1', 'success', '2026-04-08 17:56:18'),
(466, 5, 'Resolved Alert ID: 31', '::1', 'success', '2026-04-08 17:57:41'),
(467, 5, 'Viewed Activity Logs', '::1', 'success', '2026-04-08 17:58:58'),
(468, 5, 'Viewed Reports', '::1', 'success', '2026-04-08 18:36:49'),
(469, 5, 'Viewed Report ID: 9', '::1', 'success', '2026-04-08 18:38:20'),
(470, 5, 'Exported Report ID: 9 as PDF', '::1', 'success', '2026-04-08 18:41:39'),
(471, 5, 'Resolved Alert ID: 30', '::1', 'success', '2026-04-08 20:55:04'),
(472, 5, 'User Logout', '::1', 'success', '2026-04-08 20:59:21'),
(473, 5, 'User Logout', '::1', 'success', '2026-04-08 21:06:24'),
(474, 5, 'User Logout', '::1', 'success', '2026-04-08 21:40:52'),
(475, 5, 'User Login', '::1', 'success', '2026-04-08 21:41:02'),
(476, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:41:02'),
(477, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:41:08'),
(478, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:41:16'),
(479, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:41:41'),
(480, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:41:50'),
(481, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:00'),
(482, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:01'),
(483, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:02'),
(484, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:04'),
(485, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:05'),
(486, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:06'),
(487, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:07'),
(488, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:09'),
(489, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:10'),
(490, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:11'),
(491, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:13'),
(492, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:15'),
(493, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:16'),
(494, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:17'),
(495, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:18'),
(496, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:19'),
(497, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:20'),
(498, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:21'),
(499, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:22'),
(500, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:23'),
(501, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 21:42:25'),
(502, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-08 23:04:37'),
(503, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-08 23:04:40'),
(504, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:04:45'),
(505, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:04:55'),
(506, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:03'),
(507, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:05:04'),
(508, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:05:08'),
(509, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:05:08'),
(510, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:14'),
(511, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:18'),
(512, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:19'),
(513, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:20'),
(514, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:21'),
(515, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:22'),
(516, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:05:30'),
(517, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:05:33'),
(518, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:05:33'),
(519, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:39'),
(520, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:43'),
(521, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:45'),
(522, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:46'),
(523, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:47'),
(524, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:48'),
(525, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:05:52'),
(526, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:05:56'),
(527, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:05:57'),
(528, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:05:59'),
(529, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:06:03'),
(530, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:06:07'),
(531, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:06:10'),
(532, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:06:10'),
(533, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:06:13'),
(534, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-08 23:06:20'),
(535, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-08 23:06:31'),
(536, 5, 'Viewed Single Report', '::1', 'success', '2026-04-08 23:06:35'),
(537, 5, 'Exported Report PDF', '::1', 'success', '2026-04-08 23:06:41'),
(538, 5, 'Exported Report PDF', '::1', 'success', '2026-04-08 23:06:42'),
(539, 5, 'Exported Report PDF', '::1', 'success', '2026-04-08 23:06:42'),
(540, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:06:53'),
(541, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-08 23:06:58'),
(542, 0, 'Failed Login Attempt', '::1', 'failed', '2026-04-08 23:07:30'),
(543, 0, 'Failed Login Attempt', '::1', 'failed', '2026-04-08 23:07:35'),
(544, 0, 'Failed Login Attempt', '::1', 'failed', '2026-04-08 23:07:41'),
(545, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:07:54'),
(546, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:07:59'),
(547, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:08:09'),
(548, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:08:09'),
(549, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:08:11'),
(550, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:08:11'),
(551, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:08:18'),
(552, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:08:19'),
(553, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:08:26'),
(554, 5, 'Viewed Blocked IPs Page', '::1', 'success', '2026-04-08 23:08:33'),
(555, 5, 'Unblocked IP Address: ::1', '::1', 'success', '2026-04-08 23:08:36'),
(556, 5, 'Viewed Blocked IPs Page', '::1', 'success', '2026-04-08 23:08:36'),
(557, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:08:40'),
(558, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:08:44'),
(559, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:08:46'),
(560, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:08:47'),
(561, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:08:48'),
(562, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:08:49'),
(563, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:08:55'),
(564, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:08:59'),
(565, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:08:59'),
(566, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:09:03'),
(567, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:09:11'),
(568, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:09:22'),
(569, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:09:29'),
(570, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:09:29'),
(571, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:09:34'),
(572, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:09:37'),
(573, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:09:40'),
(574, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:09:45'),
(575, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:09:45'),
(576, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:09:47'),
(577, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-08 23:09:49'),
(578, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:09:52'),
(579, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:09:57'),
(580, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:10:01'),
(581, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:10:01'),
(582, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:10:11'),
(583, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:10:20'),
(584, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:10:22'),
(585, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:10:28'),
(586, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:10:29'),
(587, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:10:40'),
(588, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:10:45'),
(589, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:10:45'),
(590, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:10:49'),
(591, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:10:54'),
(592, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:10:55'),
(593, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:10:56'),
(594, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:11:15'),
(595, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:11:18'),
(596, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:11:18'),
(597, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:11:21'),
(598, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-08 23:11:42'),
(599, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-08 23:11:58'),
(600, 5, 'Viewed Single Report', '::1', 'success', '2026-04-08 23:12:02'),
(601, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:12:04'),
(602, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-08 23:12:07'),
(603, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:12:28'),
(604, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:13'),
(605, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:17'),
(606, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:35:21'),
(607, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:35:25'),
(608, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:35:25'),
(609, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:27'),
(610, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:30'),
(611, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:32'),
(612, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:33'),
(613, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:35'),
(614, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:36'),
(615, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:37'),
(616, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:38'),
(617, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:35:45'),
(618, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:35:49'),
(619, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:35:49'),
(620, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:35:51'),
(621, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:36:01'),
(622, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:36:04'),
(623, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:36:04'),
(624, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:36:09'),
(625, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:36:22'),
(626, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:36:29'),
(627, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:36:29'),
(628, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:36:33'),
(629, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:36:44'),
(630, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:36:45'),
(631, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:36:47'),
(632, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:36:48'),
(633, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:36:49'),
(634, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:36:50'),
(635, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:36:51'),
(636, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:36:55'),
(637, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:36:59'),
(638, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:36:59'),
(639, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:37:04'),
(640, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:37:22'),
(641, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:37:27'),
(642, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:37:27'),
(643, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:37:31'),
(644, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:37:34'),
(645, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:37:49'),
(646, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:37:49'),
(647, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:15'),
(648, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:18'),
(649, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:19'),
(650, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:20'),
(651, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:21'),
(652, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:22'),
(653, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:23'),
(654, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:24'),
(655, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:25'),
(656, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:38:29'),
(657, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:38:34'),
(658, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:38:34'),
(659, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:37'),
(660, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:38:40'),
(661, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:38:45'),
(662, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:38:45'),
(663, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:47'),
(664, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:38:52'),
(665, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:38:57'),
(666, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:38:58'),
(667, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:38:59'),
(668, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:39:02'),
(669, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:49:40'),
(670, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:49:40'),
(671, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:49:42'),
(672, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:49:46'),
(673, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:49:47'),
(674, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:49:49'),
(675, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:49:50'),
(676, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:49:51'),
(677, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:49:52'),
(678, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:49:54'),
(679, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:49:55'),
(680, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:49:56'),
(681, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:50:00'),
(682, 5, 'Resolved Alert', '::1', 'success', '2026-04-08 23:50:03'),
(683, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:50:03'),
(684, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-08 23:50:05'),
(685, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-08 23:50:30'),
(686, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-08 23:50:32'),
(687, 5, 'Viewed Blocked IPs Page', '::1', 'success', '2026-04-08 23:50:33'),
(688, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-08 23:50:35'),
(689, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-08 23:50:37'),
(690, 5, 'User Logout', '::1', 'success', '2026-04-08 23:50:50'),
(691, 5, 'User Login', '::1', 'success', '2026-04-10 13:22:36'),
(692, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:22:37'),
(693, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 13:22:41'),
(694, 5, 'Viewed Single Report', '::1', 'success', '2026-04-10 13:22:45'),
(695, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 13:22:48'),
(696, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 13:22:49'),
(697, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 13:23:33'),
(698, 5, 'Viewed Single Report', '::1', 'success', '2026-04-10 13:23:39'),
(699, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 13:23:46'),
(700, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 13:23:49'),
(701, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:02'),
(702, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:07'),
(703, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:08'),
(704, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:09'),
(705, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:09'),
(706, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:10'),
(707, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:11'),
(708, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:12'),
(709, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:13'),
(710, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:13'),
(711, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 13:24:16'),
(712, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:21'),
(713, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 13:24:23'),
(714, 5, 'Resolved Alert', '::1', 'success', '2026-04-10 13:24:26'),
(715, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 13:24:26'),
(716, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:31'),
(717, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 13:24:34'),
(718, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:24:52'),
(719, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 13:24:54'),
(720, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:25:06'),
(721, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:25:11'),
(722, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:25:12'),
(723, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:25:12'),
(724, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:25:13'),
(725, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:25:13'),
(726, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:25:14'),
(727, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:25:15'),
(728, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 13:25:24'),
(729, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 13:25:30'),
(730, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 13:25:36'),
(731, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:25:40'),
(732, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 13:25:42'),
(733, 5, 'Resolved Alert', '::1', 'success', '2026-04-10 13:25:45'),
(734, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 13:25:45'),
(735, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 13:25:54'),
(736, 5, 'User Login', '::1', 'success', '2026-04-10 13:34:04'),
(737, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:34:04'),
(738, 5, 'User Logout', '::1', 'success', '2026-04-10 13:35:50'),
(739, NULL, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 13:41:44'),
(740, NULL, 'Viewed Blocked IPs Page', '::1', 'success', '2026-04-10 13:42:33'),
(741, 5, 'User Login', '::1', 'success', '2026-04-10 13:45:54'),
(742, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:45:54'),
(743, 0, 'Failed Login Attempt', '::1', 'failed', '2026-04-10 13:46:11'),
(744, 0, 'Failed Login Attempt', '::1', 'failed', '2026-04-10 13:46:15'),
(745, 0, 'Failed Login Attempt', '::1', 'failed', '2026-04-10 13:46:20'),
(746, NULL, 'Viewed Blocked IPs Page', '::1', 'success', '2026-04-10 13:46:36'),
(747, 5, 'User Login', '::1', 'success', '2026-04-10 13:47:23'),
(748, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:47:23'),
(749, NULL, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 13:47:28'),
(750, 5, 'User Login', '::1', 'success', '2026-04-10 13:47:43'),
(751, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:47:43'),
(752, NULL, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 13:47:47'),
(753, 5, 'User Login', '::1', 'success', '2026-04-10 13:48:03'),
(754, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 13:48:03'),
(755, NULL, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 13:48:06'),
(756, 5, 'User Login', '::1', 'success', '2026-04-10 14:21:34'),
(757, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:21:34'),
(758, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 14:21:38'),
(759, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 14:21:41'),
(760, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:21:55'),
(761, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 14:21:58'),
(762, NULL, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 14:28:55'),
(763, NULL, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 14:31:14'),
(764, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 14:37:25'),
(765, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:37:37'),
(766, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 14:37:39'),
(767, 5, 'Resolved Alert', '::1', 'success', '2026-04-10 14:37:41'),
(768, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 14:37:41'),
(769, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:37:43'),
(770, NULL, 'Viewed Reports Page', '::1', 'success', '2026-04-10 14:37:49'),
(771, 5, 'User Login', '::1', 'success', '2026-04-10 14:49:44'),
(772, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:49:44'),
(773, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 14:49:48'),
(774, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 14:49:49'),
(775, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:49:52'),
(776, 5, 'Viewed Blocked IPs Page', '::1', 'success', '2026-04-10 14:49:54'),
(777, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 14:49:56'),
(778, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:50:01'),
(779, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 14:50:05'),
(780, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:50:08'),
(781, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 14:50:11'),
(782, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:50:20'),
(783, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 14:50:23'),
(784, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 14:50:26'),
(785, 5, 'Viewed Blocked IPs Page', '::1', 'success', '2026-04-10 14:50:31'),
(786, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 14:50:36'),
(787, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:50:41'),
(788, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 14:50:43'),
(789, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:50:47'),
(790, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:50:51'),
(791, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:50:52'),
(792, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:50:53'),
(793, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:50:54'),
(794, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:50:55'),
(795, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 14:50:59'),
(796, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:51:03'),
(797, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 14:51:05'),
(798, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:51:06'),
(799, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 14:51:08'),
(800, 5, 'Resolved Alert', '::1', 'success', '2026-04-10 14:51:10'),
(801, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 14:51:10'),
(802, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 14:51:12'),
(803, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 14:51:16'),
(804, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:36'),
(805, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:39'),
(806, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:40'),
(807, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:41'),
(808, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:42'),
(809, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:43'),
(810, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:43'),
(811, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:44'),
(812, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:45'),
(813, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:46'),
(814, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:03:49'),
(815, 5, 'Resolved Alert', '::1', 'success', '2026-04-10 15:03:53'),
(816, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:03:53'),
(817, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:03:57'),
(818, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:04:02'),
(819, 5, 'Resolved Alert', '::1', 'success', '2026-04-10 15:04:05'),
(820, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:04:05'),
(821, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:04:06'),
(822, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:04:14'),
(823, 5, 'Resolved Alert', '::1', 'success', '2026-04-10 15:04:17'),
(824, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:04:17'),
(825, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:04:20'),
(826, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 15:04:22'),
(827, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:04:34'),
(828, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 15:04:40'),
(829, 5, 'Viewed Single Report', '::1', 'success', '2026-04-10 15:04:44'),
(830, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:04:51'),
(831, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:04:52'),
(832, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:04:54'),
(833, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 15:05:12'),
(834, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:05:15'),
(835, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:05:21'),
(836, 5, 'Resolved Alert', '::1', 'success', '2026-04-10 15:05:26'),
(837, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:05:26'),
(838, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:05:29'),
(839, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:05:35'),
(840, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 15:05:40'),
(841, 5, 'Viewed Single Report', '::1', 'success', '2026-04-10 15:05:48'),
(842, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:05:50'),
(843, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:05:50'),
(844, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 15:06:01'),
(845, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:06:06'),
(846, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:06:13'),
(857, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:20:57'),
(858, 5, 'Resolved Alert ID: 64', '::1', 'success', '2026-04-10 15:21:03'),
(859, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:21:03'),
(870, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:21:21'),
(871, 5, 'Resolved Alert ID: 65', '::1', 'success', '2026-04-10 15:21:24'),
(872, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:21:24'),
(873, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:21:27'),
(874, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 15:21:30'),
(875, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:22:34'),
(876, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 15:22:38'),
(877, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 15:22:46'),
(878, 5, 'Viewed Single Report', '::1', 'success', '2026-04-10 15:22:56'),
(879, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:23:03'),
(880, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:23:04'),
(881, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:23:14'),
(882, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:23:21'),
(883, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 15:23:45'),
(884, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 15:36:28'),
(885, 5, 'Viewed Single Report', '::1', 'success', '2026-04-10 15:36:34'),
(886, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:36:38'),
(887, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 15:36:38'),
(888, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 15:36:49'),
(889, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:36:57'),
(890, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 15:37:01'),
(891, 5, 'User Logout', '::1', 'success', '2026-04-10 15:37:23'),
(892, 5, 'User Login', '::1', 'success', '2026-04-10 15:41:09'),
(893, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 15:41:09'),
(894, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 15:41:27'),
(895, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 15:41:30'),
(896, 5, 'Viewed Blocked IPs Page', '::1', 'success', '2026-04-10 15:41:31'),
(897, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 15:41:38'),
(898, 5, 'User Logout', '::1', 'success', '2026-04-10 15:42:00'),
(899, 0, 'Failed Login Attempt', '::1', 'failed', '2026-04-10 16:49:15'),
(900, 0, 'Failed Login Attempt', '::1', 'failed', '2026-04-10 16:49:33'),
(901, 0, 'Failed Login Attempt', '::1', 'failed', '2026-04-10 16:50:23'),
(902, 0, 'Failed Login Attempt', '::1', 'failed', '2026-04-10 16:51:29'),
(903, 5, 'User Login', '::1', 'success', '2026-04-10 16:57:04'),
(904, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 16:57:04'),
(905, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 16:57:22'),
(906, 5, 'Resolved Alert ID: 66', '::1', 'success', '2026-04-10 16:57:48'),
(907, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 16:57:48'),
(908, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 16:57:50'),
(909, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 16:57:57'),
(910, 5, 'Viewed Single Report', '::1', 'success', '2026-04-10 16:58:16'),
(911, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 16:58:35'),
(912, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 16:58:35'),
(913, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 16:59:06'),
(914, 5, 'Exported Report PDF', '::1', 'success', '2026-04-10 16:59:13'),
(915, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 16:59:23'),
(916, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 16:59:25'),
(917, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 16:59:30'),
(918, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:00:22'),
(919, 5, 'Viewed Blocked IPs Page', '::1', 'success', '2026-04-10 17:00:28'),
(920, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:01:34'),
(921, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:12'),
(922, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:13'),
(923, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:14'),
(924, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:15'),
(925, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:15'),
(926, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:16'),
(927, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:17'),
(928, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:17'),
(929, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:18'),
(930, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:19'),
(931, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 17:02:26'),
(932, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:02:30'),
(933, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 17:02:32'),
(934, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:03:01'),
(935, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 17:04:07'),
(936, 5, 'Resolved Alert ID: 67', '::1', 'success', '2026-04-10 17:04:10'),
(937, 5, 'Viewed Alerts Page', '::1', 'success', '2026-04-10 17:04:10'),
(938, 5, 'Viewed Dashboard', '::1', 'success', '2026-04-10 17:05:17'),
(939, 5, 'Viewed Activity Logs Page', '::1', 'success', '2026-04-10 17:05:21'),
(940, 5, 'Viewed Reports Page', '::1', 'success', '2026-04-10 17:14:07');

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE `alerts` (
  `alert_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `alert_type` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `time_detected` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT NULL,
  `seen` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alerts`
--

INSERT INTO `alerts` (`alert_id`, `user_id`, `alert_type`, `description`, `ip_address`, `time_detected`, `status`, `seen`) VALUES
(30, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 16:38:00', 'resolved', 1),
(31, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 16:45:51', 'resolved', 1),
(32, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 21:42:02', 'resolved', 1),
(33, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:05:22', 'resolved', 1),
(34, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:05:39', 'resolved', 1),
(35, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:05:59', 'resolved', 1),
(36, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:06:13', 'resolved', 1),
(37, NULL, 'Brute Force Attempt', 'Too many failed login attempts detected', '::1', '2026-04-08 23:07:41', 'resolved', 1),
(38, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:08:49', 'resolved', 1),
(39, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:09:03', 'resolved', 1),
(40, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:09:34', 'resolved', 1),
(41, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:09:47', 'resolved', 1),
(42, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:10:29', 'resolved', 1),
(43, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:10:56', 'resolved', 1),
(44, NULL, 'Suspicious Activity', 'Too many dashboard refreshes detected', '::1', '2026-04-08 23:11:21', 'resolved', 1),
(45, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:35:38', 'resolved', 1),
(46, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:35:51', 'resolved', 1),
(47, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:36:09', 'resolved', 1),
(48, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:36:51', 'resolved', 1),
(49, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:37:04', 'resolved', 1),
(50, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:37:31', 'resolved', 1),
(51, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:38:25', 'resolved', 1),
(52, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:38:37', 'resolved', 1),
(53, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:38:47', 'resolved', 1),
(54, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:39:00', 'resolved', 1),
(55, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-08 23:49:56', 'resolved', 1),
(56, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-10 13:24:13', 'resolved', 1),
(57, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-10 13:25:14', 'resolved', 1),
(58, NULL, 'Brute Force Attempt', 'Too many failed login attempts detected', '::1', '2026-04-10 13:46:20', 'resolved', 1),
(59, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-10 14:50:55', 'resolved', 1),
(60, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-10 15:03:46', 'resolved', 1),
(61, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-10 15:03:57', 'resolved', 1),
(62, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-10 15:04:06', 'resolved', 1),
(63, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-10 15:04:20', 'resolved', 1),
(64, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-10 15:20:54', 'resolved', 1),
(65, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-10 15:21:19', 'resolved', 1),
(66, NULL, 'Brute Force Attempt', 'Too many failed login attempts detected', '::1', '2026-04-10 16:50:23', 'resolved', 1),
(67, NULL, 'Dashboard Flooding', 'Dashboard was refreshed continuously 10 times within 1 minute', '::1', '2026-04-10 17:02:18', 'resolved', 1);

-- --------------------------------------------------------

--
-- Table structure for table `authorized_users`
--

CREATE TABLE `authorized_users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `reference_number` varchar(50) NOT NULL,
  `used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `authorized_users`
--

INSERT INTO `authorized_users` (`id`, `full_name`, `reference_number`, `used`, `created_at`) VALUES
(1, 'HARUNA ABDUL-WARIS', 'UWB3201622', 1, '2026-04-08 16:14:02'),
(2, 'ZACHARIAH FUSEINI AGBO', 'UWB3202922', 0, '2026-04-08 16:14:02'),
(3, 'GAMOR KELVIN', 'UWB3205124', 1, '2026-04-08 16:14:02'),
(4, 'Ali Baba', 'UWB3201722', 0, '2026-04-08 16:14:02');

-- --------------------------------------------------------

--
-- Table structure for table `blocked_ips`
--

CREATE TABLE `blocked_ips` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `blocked_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `attempt_id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `attempt_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`attempt_id`, `username`, `ip_address`, `attempt_time`, `status`) VALUES
(97, 'waris11', '::1', '2026-04-08 16:37:20', 'success');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `report_id` int(11) NOT NULL,
  `alert_type` varchar(100) DEFAULT NULL,
  `report_title` varchar(255) DEFAULT NULL,
  `report_content` text DEFAULT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`report_id`, `alert_type`, `report_title`, `report_content`, `generated_at`, `status`) VALUES
(9, 'Suspicious Activity', 'Security Alert Report - Suspicious Activity', 'Company Security Alert Report\n----------------------------------\nAlert Type: Suspicious Activity\nDescription: Too many dashboard refreshes detected\nIP Address: ::1\nGenerated At: 2026-04-08 18:38:00\nStatus: Active\n', '2026-04-08 16:38:00', 'exported'),
(10, 'Suspicious Activity', 'Security Alert Report - Suspicious Activity', 'Company Security Alert Report\n----------------------------------\nAlert Type: Suspicious Activity\nDescription: Too many dashboard refreshes detected\nIP Address: ::1\nGenerated At: 2026-04-08 16:45:51\nStatus: Active\n', '2026-04-08 16:45:51', 'generated'),
(11, 'Dashboard Flooding', 'Security Report - Dashboard Flooding', 'Alert Type: Dashboard Flooding\nDescription: Dashboard was refreshed continuously 10 times within 1 minute\nIP Address: ::1\nGenerated At: 2026-04-10 15:03:46', '2026-04-10 15:03:46', 'generated'),
(12, 'Dashboard Flooding', 'Security Report - Dashboard Flooding', 'Alert Type: Dashboard Flooding\nDescription: Dashboard was refreshed continuously 10 times within 1 minute\nIP Address: ::1\nGenerated At: 2026-04-10 15:03:57', '2026-04-10 15:03:57', 'generated'),
(13, 'Dashboard Flooding', 'Security Report - Dashboard Flooding', 'Alert Type: Dashboard Flooding\nDescription: Dashboard was refreshed continuously 10 times within 1 minute\nIP Address: ::1\nGenerated At: 2026-04-10 15:04:06', '2026-04-10 15:04:06', 'generated'),
(14, 'Dashboard Flooding', 'Security Report - Dashboard Flooding', 'Alert Type: Dashboard Flooding\nDescription: Dashboard was refreshed continuously 10 times within 1 minute\nIP Address: ::1\nGenerated At: 2026-04-10 15:04:20', '2026-04-10 15:04:20', 'generated'),
(15, 'Dashboard Flooding', 'Security Report - Dashboard Flooding', 'Alert Type: Dashboard Flooding\nDescription: Dashboard was refreshed continuously 10 times within 1 minute\nIP Address: ::1\nGenerated At: 2026-04-10 15:20:54', '2026-04-10 15:20:54', 'generated'),
(16, 'Dashboard Flooding', 'Security Report - Dashboard Flooding', 'Alert Type: Dashboard Flooding\nDescription: Dashboard was refreshed continuously 10 times within 1 minute\nIP Address: ::1\nGenerated At: 2026-04-10 15:21:19', '2026-04-10 15:21:19', 'Exported'),
(17, 'Brute Force Attempt', 'Security Report - Brute Force Attempt', 'Alert Type: Brute Force Attempt\nDescription: Too many failed login attempts detected\nIP Address: ::1\nGenerated At: 2026-04-10 16:50:23', '2026-04-10 16:50:23', 'Exported'),
(18, 'Dashboard Flooding', 'Security Report - Dashboard Flooding', 'Alert Type: Dashboard Flooding\nDescription: Dashboard was refreshed continuously 10 times within 1 minute\nIP Address: ::1\nGenerated At: 2026-04-10 17:02:18', '2026-04-10 17:02:18', 'generated');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `reference_number`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(5, 'HARUNA ABDUL-WARIS', 'UWB3201622', 'waris11', 'waris11@gmail.com', '$2y$10$nGFyWalNuc8oOcCyVEnfneOj/HFRBL/qrlhuvu.qYJVJJYyouZM.6', 'user', '2026-04-08 16:34:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `alerts`
--
ALTER TABLE `alerts`
  ADD PRIMARY KEY (`alert_id`);

--
-- Indexes for table `authorized_users`
--
ALTER TABLE `authorized_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference_number` (`reference_number`);

--
-- Indexes for table `blocked_ips`
--
ALTER TABLE `blocked_ips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`attempt_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference_number` (`reference_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=941;

--
-- AUTO_INCREMENT for table `alerts`
--
ALTER TABLE `alerts`
  MODIFY `alert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `authorized_users`
--
ALTER TABLE `authorized_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `blocked_ips`
--
ALTER TABLE `blocked_ips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `attempt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
